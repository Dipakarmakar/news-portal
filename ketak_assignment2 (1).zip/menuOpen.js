document.querySelector(".menuBarIcon").addEventListener("click", () => {
  if (document.querySelector(".menuItem").style.display == "none") {
    document.querySelector(".menuItem").style.display = "flex";
  } else {
    document.querySelector(".menuItem").style.display = "none";
  }
});
