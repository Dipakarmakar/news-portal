window.addEventListener("scroll", () => {
  const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
  //   console.log({ scrollTop, scrollHeight, clientHeight });
  if (clientHeight + scrollTop >= scrollHeight - 5) {
    createNews();
    createNews();
    createNews();
    createNews();
    createNews();
    createNews();
  }
});

createNews = () => {
  const newNews = document.createElement("div");
  newNews.classList.add("newsSugestion");
  newNews.innerHTML = `<div class="newsSugestionNewsImg">
    <img src="./news.png" alt="newsImg" />
  </div>
  <div class="newsSugestionRightItems">
    <div class="newsSugestionRightItemsNewsHeadline">
      <a href="#"
        >Chine and Russia strengthen Ties with President Xi Visit to
        Moscow</a
      >
    </div>
    <div class="newsSugestionRightItemsNewsCategory">Latest News</div>
  </div>`;

  document.querySelector(".newsSugestions").appendChild(newNews);
};
