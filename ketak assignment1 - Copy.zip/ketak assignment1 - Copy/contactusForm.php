<?php 
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "form"; 
 
// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 
// Check connection 
if ($conn->connect_error) { 
  die("Connection failed: " . $conn->connect_error); 
} 
 
$name=$_POST['contactUsName']; 
$email=$_POST['contactUsEmail']; 
$message=$_POST['contactUsMessage']; 
 
 
$sql = "INSERT INTO contactus (Name, Email, Message) VALUES ('$name', '$email', '$message')"; 
 
if ($conn->query($sql) === TRUE) { 
  echo "New record created successfully"; 
} else { 
  echo "Error: " . $sql . "<br>" . $conn->error; 
} 
 
$conn->close(); 
?>