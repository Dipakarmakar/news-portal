// chatbot js start 
document.querySelector(".chatBot").addEventListener("click", () => { 
    if (document.querySelector(".chatBotOpened").style.display == "block") { 
      document.querySelector(".chatBotOpened").style.display = "none"; 
      document.querySelector(".chatBot").style.backgroundColor = "orange"; 
      document.querySelector(".chatBot").innerHTML = 
        '<i class="fa-solid fa-message">'; 
    } else { 
      document.querySelector(".chatBotOpened").style.display = "block"; 
      document.querySelector(".chatBot").style.backgroundColor = "#404040"; 
      document.querySelector(".chatBot").innerHTML = 
        '<i class="fa-solid fa-xmark"></i>'; 
    } 
  }); 
   
  document.querySelector(".sendBtn").addEventListener("click", () => { 
    if ( 
      document.getElementById("chtName").value &&  
      document.getElementById("chtEmail").value && 
      document.getElementById("chtHelp").value 
    ) { 
      document.getElementById("chatBotFormFields").submit(); 
    } else { 
      alert("Please fill all information!"); 
    } 
  }); 
   
  // chatbot js end