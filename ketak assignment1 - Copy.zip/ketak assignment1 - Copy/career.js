let noOfResumes = document.getElementById("noOfResumes"); 
 
document.querySelector(".attachmentFiles").addEventListener("click", () => { 
  let resumeFile = document.createElement("input"); 
  resumeFile.type = "file"; 
  resumeFile.click(); 
  resumeFile.onchange = () => { 
    if (resumeFile.files) { 
      noOfResumes.innerHTML = "1"; 
    } 
  }; 
}); 
window.onscroll = () => { 
  if (window.pageYOffset > 0) { 
    document.getElementById("sitelogo").style.width = "160px"; 
    document.getElementById("sitelogo").style.height = "80px"; 
    document.getElementById("header").style.backgroundColor = 
      "rgba(13,13,13,0.9)"; 
  } else { 
    document.getElementById("sitelogo").style.width = "190px"; 
    document.getElementById("sitelogo").style.height = "100px"; 
    document.getElementById("header").style.backgroundColor = "rgb(13,13,13)"; 
  } 
}; 
 
document.querySelector(".submitButton").addEventListener("click", () => { 
  if ( 
    document.getElementById("careerName").value && 
    document.getElementById("careerPhone").value && 
    document.getElementById("careerEmail").value && 
    document.getElementById("careerMessage").value 
  ) { 
    document.getElementById("careerForm").submit(); 
  } else { 
    alert("Please fill all information!"); 
  } 
});