window.onscroll = () => { 
    if (window.pageYOffset > 0) { 
      document.getElementById("sitelogo").style.width = "160px"; 
      document.getElementById("sitelogo").style.height = "80px"; 
      document.getElementById("header").style.backgroundColor = 
        "rgba(13,13,13,0.9)"; 
    } else { 
      document.getElementById("sitelogo").style.width = "190px"; 
      document.getElementById("sitelogo").style.height = "100px"; 
      document.getElementById("header").style.backgroundColor = "rgb(13,13,13)"; 
    } 
  }; 
   
  //opening timings dropdown 
  document.querySelector(".openingTimings").addEventListener("click", () => { 
    document.querySelector(".openingTimings").style.display = "none"; 
    document.querySelector(".openingTimingsOpened").style.display = "flex"; 
  }); 
   
  document 
    .querySelector(".openingTimingsOpenedFirstChild") 
    .addEventListener("click", () => { 
      document.querySelector(".openingTimings").style.display = "flex"; 
      document.querySelector(".openingTimingsOpened").style.display = "none"; 
    }); 
   
  //send message form show 
  document 
    .querySelector(".openingTimingsSendMessagebtn") 
    .addEventListener("click", () => { 
      document.querySelector(".beforeSendMessagebtnClick").style.display = "none"; 
      document.querySelector(".afterSendMessagebtnClick").style.display = "block"; 
    }); 
   
  document 
    .querySelector(".afterSendMessagebtnClickCancel") 
    .addEventListener("click", () => { 
      document.querySelector(".beforeSendMessagebtnClick").style.display = 
        "block"; 
      document.querySelector(".afterSendMessagebtnClick").style.display = "none"; 
    }); 
   
  //contactus form submit 
  document 
    .querySelector(".afterSendMessagebtnClickSendbtnCancelSendbtn") 
    .addEventListener("click", () => { 
      document 
        .querySelector(".afterSendMessagebtnClickSendbtnCancelSendbtn") 
        .addEventListener("click", () => { 
          if ( 
            document.getElementById("afterSendMessagebtnClickFormName").value && 
            document.getElementById("afterSendMessagebtnClickFormEmail").value && 
            document.getElementById("afterSendMessagebtnClickFormMessage").value 
          ) { 
            document.getElementById("afterSendMessagebtnClickFormBody").submit(); 
          } else { 
            alert("Please fill all information!"); 
          } 
        }); 
    });