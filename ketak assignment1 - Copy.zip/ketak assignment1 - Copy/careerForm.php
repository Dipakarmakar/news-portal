<?php 
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "form"; 
 
// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 
// Check connection 
if ($conn->connect_error) { 
  die("Connection failed: " . $conn->connect_error); 
} 
 
$name=$_POST['careerName']; 
$phone=$_POST['careerPhone']; 
$email=$_POST['careerEmail']; 
$message=$_POST['careerMessage']; 
 
 
$sql = "INSERT INTO career (name, phone, email, message) VALUES ('$name', '$phone', '$email', '$message')"; 
 
if ($conn->query($sql) === TRUE) { 
  echo "New record created successfully"; 
} else { 
  echo "Error: " . $sql . "<br>" . $conn->error; 
} 
 
$conn->close(); 
?>